#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, os.path, sys, tempfile, shutil, re
from os.path import expanduser
from epub_utils import epub_zip_up_book_contents

try:
    from sigil_bs4 import BeautifulSoup, Tag
except:
    from bs4 import BeautifulSoup, Tag

def GetDesktop():
    # output directory
    home = expanduser('~')
    desktop = os.path.join(home, 'Desktop')
    if os.path.isdir(desktop):
        return desktop
    else:
        return home

# credit: DiapDealer 
# https://www.mobileread.com/forums/showpost.php?p=3575920&postcount=229        
def find_python3lib_dir(appdir):
    extralibdir = None
    # Determine python3lib path per platform
    if sys.platform.startswith('darwin'):
        extralibdir = os.path.join(appdir, '../python3lib')
    elif sys.platform.startswith('win'):
        extralibdir = os.path.join(appdir, 'python3lib')
    else:
        for path in sys.path:
            if 'plugin_launchers/python' in path:
                extralibdir = os.path.join(path, '../../python3lib')
                break
    return extralibdir        

# stolen from epub3-tizer plugin
def cleanup_file_name(name):
    import string
    _filename_sanitize = re.compile(r'[\xae\0\\|\?\*<":>\+/]')
    substitute='_'
    one = ''.join(char for char in name if char in string.printable)
    one = _filename_sanitize.sub(substitute, one)
    one = re.sub(r'\s', '_', one).strip()
    one = re.sub(r'^\.+$', '_', one)
    one = one.replace('..', substitute)
    # Windows doesn't like path components that end with a period
    if one.endswith('.'):
        one = one[:-1]+substitute
    # Mac and Unix don't like file names that begin with a full stop
    if len(one) > 0 and one[0:1] == '.':
        one = substitute+one[1:]
    return one

# main routine
def run(bk):
    # this plugin only works with standard file paths
    if bk.launcher_version() >= 20190927 and not bk.epub_is_standard():
        print('This plugin only works with standard epubs.\nPlease select Tools > Restructure to Sigil Norm before running this plugin.\n\nClick OK to close the Plugin Runner window.')
        return 0

    # get epub version number
    if bk.launcher_version() >= 20160102:
        epubversion = bk.epub_version()
    else:
        epubversion = BeautifulSoup(bk.get_opf(), 'lxml').find('package')['version']

    if epubversion.startswith('2'):
        print('This plugin only works with epub3 files!')
        return -1

    # locate python3lib
    python3lib = find_python3lib_dir(bk._w.appdir)
    # Prepend python3lib directory to sys.path
    if python3lib is not None and os.path.exists(python3lib) and os.path.isdir(python3lib):
        sys.path.insert(0, os.path.abspath(python3lib))
        from ncxgenerator import generateNCX, generateGuideEntries
    else:
        print('Couldn\'t add python3lib directory to sys.path!')
        
    #======================
    # get preferences
    #======================
    prefs = bk.getPrefs()
    
    # controls epub:type attribute handing; if false, epub:type attrs will be converted to class attributes 
    if 'delete_epub_type' in prefs:
        delete_epub_type = prefs['delete_epub_type']
    else:
        delete_epub_type = False
        prefs['delete_epub_type'] = delete_epub_type
        bk.savePrefs(prefs)
        
    # controls whether the ncx should be automatically generated from the nav; if true the ncx will always be generated
    if 'ncx_from_nav' in prefs:
        ncx_from_nav = prefs['ncx_from_nav']
    else:
        ncx_from_nav = False
        prefs['ncx_from_nav'] = ncx_from_nav
        bk.savePrefs(prefs)
        
    # epub2 output directory; default = desktop
    if 'output_dir' in prefs and os.path.isdir(prefs['output_dir']):
        output_dir = prefs['output_dir']
    else:
        output_dir = GetDesktop()
        prefs['output_dir'] = output_dir
        bk.savePrefs(prefs)

    #====================
    # copy original epub files
    #====================

    # create temp folder
    temp_dir = tempfile.mkdtemp()

    # copy book files
    bk.copy_book_contents_to(temp_dir)

    # write mimetype file
    with open(os.path.join(temp_dir, "mimetype"), "w") as mimetype:
        mimetype.write("application/epub+zip")

    # load content.opf to bs4
    opf_soup = BeautifulSoup(bk.get_opf(), 'xml')

    #================
    # Update content.opf
    #================
    print('Processing content.opf...\n')

    #--------------------------------------------------
    # update package version number
    #--------------------------------------------------

    # change epub version number
    package = opf_soup.find('package')
    package['version'] = '2.0'
    
    #----------------------------------------
    # get fallback dtbuid for NCX
    #----------------------------------------
    dtbuid = ''
    unique_identifier = package['unique-identifier']
    dtbuid_meta =  opf_soup.find(True, {'id' : unique_identifier})
    if dtbuid_meta is not None:
        dtbuid = str(dtbuid_meta.string)

    #----------------------------------------------
    # get fallback docTitle for NCX
    #----------------------------------------------
    docTitle = ''
    dc_title =  opf_soup.metadata.find('title')
    if dc_title:
        docTitle = str(dc_title.string)

    #-------------------------------
    # remove prefix attribute
    #-------------------------------
    if 'prefix' in package.attrs:
        print(package['prefix'], 'package prefix attribute deleted.')
        del package['prefix']
    #----------------------------------
    # remove xml:lang attribute
    #----------------------------------
    if 'xml:lang' in package.attrs:
        print(package['xml:lang'], 'package xml:lang attribute deleted.')
        del package['xml:lang']
    print('Package updated.\n')
    
    #---------------------------------------
    # delete epub3 <spine> attributes
    #---------------------------------------   
    for idref in opf_soup.find_all('itemref'):
        if 'properties' in idref.attrs:
            print(idref['properties'], 'spine item attribute deleted.\nSpine updated.\n')
            del idref['properties']

    #----------------------------------------------------------
    # remove page-progression-direction attribute
    #----------------------------------------------------------
    spine = opf_soup.find('spine')
    if 'page-progression-direction' in spine.attrs:
        print('page-progression-direction spine attribute:',  spine['page-progression-direction'], ' deleted.')
        del spine['page-progression-direction']
        print('Spine updated.\n')

    #-------------------------------------------------
    # add default <metadata> namespaces
    #-------------------------------------------------
    metadata = opf_soup.find('metadata')
    if 'xmlns:opf' not in metadata.attrs:
        metadata['xmlns:opf'] = 'http://www.idpf.org/2007/opf'
    if 'xmlns:dc' not in metadata.attrs:
        metadata['xmlns:dc'] = 'http://purl.org/dc/elements/1.1/'

    #--------------------------------
    # fix time stamp attributes
    #--------------------------------
    timestamp = opf_soup.find('meta', {'property' : 'dcterms:modified'})
    timestamp.string = timestamp.string[0:10]
    del timestamp['property']
    timestamp['opf:event'] = 'modification'
    timestamp.name = 'dc:date'
    
    #-------------------------------------------------------------------------
    # try to map ROLE and FILE-AS refines to OPF attributes
    #-------------------------------------------------------------------------
    print('Mapping refines...\n')
    for refine in opf_soup.find_all('meta', {"refines" : re.compile(r".*")}):
        dc_id = refine['refines'][1:]
        dc_property = refine['property']
        dc_string =refine.string
        if dc_property == 'role':
            metadata.find(id=dc_id)['opf:role'] = refine.string
            print('"' + dc_string + '"', 'role refines attribute mapped to opf:role attribute') 
        # only <dc:creator>/<dc:contributor> tags can have a file-as attribute
        elif dc_property == 'file-as' and metadata.find(id=dc_id).name in ['creator', 'contributor']:
            metadata.find(id=dc_id)['opf:file-as'] = refine.string
            print('"' + dc_string + '"', 'file:as refines attribute mapped to opf:file-as attribute') 
        # map to Calibre equivalent
        elif dc_property == 'file-as' and metadata.find(id=dc_id).name == 'title':
            new_tag = opf_soup.new_tag('meta')
            new_tag['name'] = 'calibre:title_sort'
            new_tag['content'] = refine.string
            opf_soup.metadata.append(new_tag)
            opf_soup.metadata['xmlns:calibre'] = 'http://calibre.kovidgoyal.net/2009/metadata'
            print('"' + dc_string + '"', 'file:as refines title attribute mapped to calibre:title_sort attribute') 
        # map to Calibre equivalents
        elif dc_property == 'group-position':
            collection_name = metadata.find('meta', {"property" : "belongs-to-collection"})
            if collection_name and dc_id == collection_name['id']: 
                new_tag = opf_soup.new_tag('meta')
                new_tag['name'] = 'calibre:series'
                new_tag['content'] = collection_name.string
                opf_soup.metadata.append(new_tag)
                print('"' + collection_name.string + '"', 'belongs-to-collection refines attribute mapped to calibre:series attribute') 

                new_tag = opf_soup.new_tag('meta')
                new_tag['name'] = 'calibre:series_index'
                new_tag['content'] = refine.string
                opf_soup.metadata.append(new_tag)
                print('"' + dc_string + '"', 'group-position refines attribute mapped to calibre:series_index attribute') 
                opf_soup.metadata['xmlns:calibre'] = 'http://calibre.kovidgoyal.net/2009/metadata'
        else:
            print('"' + dc_string + '"', dc_property, 'refines property IGNORED.')
    print('Metadata updated.\n')

    #---------------------------------------------------------
    # parse <manifest> PROPERTIES attributes
    #---------------------------------------------------------
    scripted = []
    navid = None
    for prop in opf_soup.find_all('item', {"properties" : re.compile(r".*")}):

        # get NAV id (used later for NCX and GUIDE generation)
        if prop['properties'] == 'nav':
            navid = bk.href_to_id(prop['href'])
            navname = os.path.basename(prop['href'])
            navdata = bk.readfile(navid)
        
        # get HTML ids of files with JavaScript code (used later for deleting inline JavaScript code)
        if prop['properties'] == 'scripted':
            if scripted == []:
                scripted = [prop['id']]
            else:
                scripted.append(prop['id'])

        # map cover-image property to cover <meta> entry, if it doesn't exist
        if prop['properties'] == 'cover-image' and not metadata.find('meta', {"name" : "cover"}):
            new_tag = Tag(builder=opf_soup.builder, name='meta', attrs={'name' : 'cover','content' : prop['id']})
            opf_soup.metadata.insert(0, new_tag)
            print('Cover image file metadata entry added.')

        # delete properties attribute
        print(prop['properties'], 'manifest properties attribute deleted.')
        del prop['properties']

    print('Manifest updated.\n')

    #============================
    # map LANDMARKS to GUIDE items
    #============================
    if bk.getguide() == [] and python3lib is not None:
        
        # generate guide from NAV and add GUIDE items
        if bk.launcher_version() < 20190927:
            guide = generateGuideEntries(navdata, nav_basename)
        else:
            # the syntax changed in Sigil 1.0
            # generateGuideEntries(nav_data, nav_bkpath, opfdir):
            opfdir = bk.get_startingdir(bk.get_opfbookpath())
            nav_bkpath = bk.id_to_bookpath(bk.getnavid())
            guide = generateGuideEntries(navdata, nav_bkpath, opfdir)        

        if guide != []:
        
            # add empty guide section
            new_tag = opf_soup.new_tag('guide')
            opf_soup.package.spine.insert_after(new_tag)
            
            print('Guide section added to content.opf.')
        
            # add guide items
            for type, href, title in guide:
                new_tag = opf_soup.new_tag('reference', href=href, title=title, type=type)
                opf_soup.guide.insert(0, new_tag)
                print(str(new_tag), 'guide item added.')

    #-------------------------------------------------------------------------------------------
    # delete all refines (and other <meta> entries with a property attribute)
    #-------------------------------------------------------------------------------------------
    print('\nDeleting refines...')
    for refine in opf_soup.find_all('meta', {"property" : re.compile(r".*")}):
        print(refine, 'deleted.')
        refine.decompose()

    # update soup (required because of decompose())
    opf_soup = BeautifulSoup(str(opf_soup), 'xml')

    #--------------------------------------------------
    # delete all <link> tags from content.opf
    #--------------------------------------------------
    for link in opf_soup.find_all('link'):
        print(link, 'deleted.')
        link.decompose()

    # update soup (required because of decompose())
    opf_soup = BeautifulSoup(str(opf_soup), 'xml')

    #-------------------------
    # delete binding tag
    #------------------------
    bindings = opf_soup.find('bindings')
    if bindings is not None:
        print('bindings tag deleted from content.opf')
        bindings.decompose()

        # update soup (required because of decompose())
        opf_soup = BeautifulSoup(str(opf_soup), 'xml')

    #-----------------------------------
    # delete spine item svg files
    #-----------------------------------
    for spine_item in opf_soup.find_all('itemref'):
        spine_id = spine_item['idref']
        manifest_item = opf_soup.find(id=spine_id)
        if manifest_item['media-type'] == 'image/svg+xml':
            print(spine_item, '(SVG file spine item) deleted.')
            spine_item.decompose()

    
    #================
    # update TOC.NCX
    #================
    ncxid = bk.gettocid()
    if (ncx_from_nav or not ncxid) and python3lib is not None:
        ncxdir = 'OEBPS'
        
        if ncxid:
            ncxname = bk.id_to_href(ncxid)
            ncxsoup = BeautifulSoup(bk.readfile(ncxid), 'xml')
            dtbuid = ncxsoup.find('meta', {'name' : 'dtb:uid'})['content']
            docTitle = ncxsoup.docTitle.text
            print('\nExisting NCX updated.')
        else:
            ncxname = 'toc.ncx'
            # add toc spine attribute
            opf_soup.package.spine['toc'] = 'ncx'
            # add toc.ncx manifest entry
            new_tag = Tag(builder=opf_soup.builder, name='item', attrs={'id' : 'ncx', 'href' : 'toc.ncx', 'media-type' : 'application/x-dtbncx+xml' })
            opf_soup.package.manifest.insert(0, new_tag)
            print('\nNew NCX generated.')
        
        if bk.launcher_version() >= 20190927:
            if ncxid:
                ncx_bookpath =  bk.id_to_bookpath(ncxid)
                ncxdir = bk.get_startingdir(ncx_bookpath)
            navbkpath = bk.id_to_bookpath(bk.getnavid())
            ncxdata =  generateNCX(navdata, navbkpath, ncxdir, docTitle, dtbuid)
        else:
            ncxdata = generateNCX(navdata, navname, docTitle, dtbuid)
        
        with open(os.path.join(temp_dir, ncxdir, ncxname), "wb") as ncx:
            ncx.write(bytes(str(ncxdata), 'utf-8'))
            print('\nNCX written.')

    #------------------------------------------------
    # write updated .opf file to temp folder
    #------------------------------------------------
    with open(os.path.join(temp_dir, 'OEBPS','content.opf'), "wb") as new_opf_file:
        new_opf_file.write(bytes(str(opf_soup), 'utf-8'))
        print('\ncontent.opf updated.')
    
    #======================
    # process HTML files
    #======================
    print('\nProcessing HTML files...\n')
    for (html_id, href) in list(bk.text_iter()):
        html = bk.readfile(html_id)
        soup = BeautifulSoup(html, 'html5lib')
        orig_soup = str(soup)
        print('Processing', href, '...')

        #------------------------------------------
        # delete <html> tag epub prefixes
        #------------------------------------------
        if 'epub:prefix' in soup.html.attrs:
            print('epub:prefix html tag attribute deleted.')
            del soup.html['epub:prefix']
        if 'xmlns:epub' in soup.html.attrs:
            print('xmlns:epub html tag attribute deleted.')
            del soup.html['xmlns:epub']
        if 'xmlns:ibooks' in soup.html.attrs:
            print('xmlns:ibooks html tag attribute deleted.')
            del soup.html['xmlns:ibooks']

        #------------------------------------------------------------------------------
        # replace all epub3 TAGS with <div>, <object> or <span> tags
        #------------------------------------------------------------------------------
        epub3_tags = ['article', 'aside', 'bdi', 'cite', 'details', 'dialog',  'epub:switch', 'epub:case', 'epub:default', 'epub:trigger', 'fieldset', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'legend', 'main', 'menuitem', 'mark', 'meter', 'nav', 'progress', 'rp', 'rt', 'ruby', 'section', 'summary', 'time', 'wbr', 'audio', 'video', 'source', 'track', 'button', 'embed']
        for epub3_tag in epub3_tags:
            all_tags = soup.find_all(epub3_tag)
            # convert tag to div
            for tag in all_tags:
                
                # check for NAV epub:type attributes
                if 'epub:type' in tag.attrs:
                    tag_value =tag['epub:type']
                    del tag['epub:type']           
                else:
                    tag_value = tag.name.replace(':', '_')

                # add tag name or epub:type attribute as tag attribute or delete it
                if not delete_epub_type:
                    if 'class' in tag.attrs:
                        tag['class'].append(tag_value)
                    else:
                        tag['class'] = tag_value
                    print('<' + tag.name + '>', tag_value, 'added as class attribute.')
                #else:
                    #print('<' + tag.name + '>', tag_value, 'attribute deleted.')

                #---------------------------------------------
                # handle special tag attributes
                #---------------------------------------------
                    
                # remove all epub:trigger attributes
                if tag.name == 'epub:trigger':
                    tag.attrs = {}

                # replace <mark> with inline style
                if tag.name == 'mark':
                    tag['style'] = 'background-color: yellow;'     

                # hide NAV toc list item marker 
                if tag_value == 'toc':
                    ordered_lists = tag.find_all('ol')
                    for ol in ordered_lists:
                        ol['style'] = 'list-style-type: none;'

                # hide NAV landmarks and page-list landmarks sections and ruby tags
                if tag_value in ['landmarks', 'page-list'] or tag.name in ['ruby', 'epub:case']:
                    tag['style'] = 'display: none;'                       
                
                # remove the required-namespace attribute of epub:case tags
                if 'required-namespace' in tag.attrs:
                    del tag['required-namespace']

                #--------------------------------------------------------------
                # change tag name to <object>, <div> or <span>
                #--------------------------------------------------------------
                if tag.name in ['audio', 'video', 'source', 'track', 'button']:
                    for attr in list(tag.attrs):
                        if attr in ['aria-controls', 'autoplay', 'button', 'controls', 'default', 'disabled', 'loop', 'role', 'srclang', 'kind', 'label', 'embed', 'poster']:
                            del tag[attr]
                        if attr == 'src':
                            tag_value = tag[attr]
                            del tag[attr]
                            tag['data'] = tag_value.replace(':', '_')
                    print('<' + tag.name + '>', 'tag changed to <object>')
                    tag.name = 'object'
                #elif tag.name in ['cite']:
                    #print('<' + tag.name + '>', 'tag changed to <p>')
                    #tag.name = 'p'
                elif tag.name not in ['ruby', 'rt', 'rp', 'mark', 'wbr', 'time', 'cite']:
                    print('<' + tag.name + '>', 'tag changed to <div>')
                    tag.name = 'div'
                else:
                    print('<' + tag.name + '>', 'tag changed to <span>')
                    tag.name = 'span'
        
        #------------------------------------------------------------------------------------
        # convert all other EPUB:TYPE attributes to classes or delete them
        #------------------------------------------------------------------------------------
        epub_type_attributes = soup.find_all(re.compile('.*?'), {'epub:type' : re.compile('.*?')}) 
        for epub_type in epub_type_attributes:
            tag_value = epub_type['epub:type']
            del epub_type['epub:type']
            if delete_epub_type:
                # delete epub:type attribute
                print('epub:type', tag_value, 'attribute deleted.')
            else:
                # add class attribute with the same value
                if 'class' in epub_type.attrs:
                    epub_type['class'].append(tag_value.replace(':', '_')) 
                else:
                    epub_type['class'] = tag_value.replace(':', '_')
                print('epub:type', tag_value, 'attribute changed to class attribute.')

        #------------------------------------------
        # delete all data-* attributes
        #------------------------------------------
        for tag in soup.find_all(lambda t: any(i.startswith('data-') for i in t.attrs)):
            for attr in list(tag.attrs):
                if attr.startswith('data-'):
                    print('{}="{}" attribute deleted.'.format(attr, tag.attrs[attr]))
                    del tag.attrs[attr]

        #------------------------------------------
        # delete all ARIA role attributes
        #-----------------------------------------
        for role_tag in soup.find_all(attrs={'role': True}):
            print('role="{}" attribute deleted.'.format(role_tag['role']))
            del role_tag['role']
                
        #------------------------------------------
        # replace all HIDDEN attributes
        #-----------------------------------------
        hidden_tags = soup.find_all(re.compile('.*?'), {'hidden' : re.compile('.*?')}) 
        for hidden_tag in hidden_tags:
            print('<' + tag_value.replace('_', ':') + '>', 'hidden attribute deleted.')
            del hidden_tag['hidden']
            hidden_tag['style'] = 'display: none;'

        #------------------------------------------------------------------
        # add missing type style attribute to INLINE STYLES
        #------------------------------------------------------------------
        style = soup.find('style')
        if style is not None and style.attrs == {}:
            style['type'] = 'text/css'

        #-----------------------------------------------
        # reformat CHARSET metadata entry
        #-----------------------------------------------
        charset = soup.find('meta', {'charset' : re.compile('.*?')})
        if charset is not None:
            charset['http-equiv'] = 'content-type'
            charset['content'] = 'text/html; charset=' + charset['charset']
            del charset['charset']

        #------------------------------------------------
        # check for embedded JAVASCRIPT code
        #------------------------------------------------
        if html_id in scripted:
            # onload attributes
            if 'onload' in soup.body.attrs:
                del soup.body['onload']
                print('Onload body attribute deleted')
            
            # onclick attributes
            onclick_attributes = soup.find_all(re.compile('.*?'), {'onclick' : re.compile('.*?')}) 
            for onclick_attribute in onclick_attributes:
                del onclick_attribute['onclick']
                print(onclick_attribute.name, 'onclick attribute deleted.')
            
            # scripts
            scripts = soup.find_all('script')
            if scripts is not None:
                for script in scripts:
                    script.decompose()
                    print('Embedded JavaScript deleted.')

        #==============================
        # write updated HTML files to temp folder
        #==============================
        new_soup = str(soup)
        if new_soup != orig_soup or new_soup.find('<!DOCTYPE html>'):
            with open(os.path.join(temp_dir, 'OEBPS', href), "wb") as html_file:
                try:
                    new_soup = str(soup.prettyprint_xhtml(indent_level=0, eventual_encoding="utf-8", formatter="minimal", indent_chars="  "))
                except:
                    new_soup =  str(soup)
                    
                # get rid of parser artifacts
                new_soup = new_soup.replace('<!--?xml version="1.0" encoding="utf-8"?-->', '')
                new_soup = new_soup.replace('<!DOCTYPE html>', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"\n  "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">')
                    
                html_file.write(bytes(new_soup, 'utf-8'))
                
            print(href, 'updated.\n')

    # define output path
    dc_title = 'Untitled'
    metadata_soup = BeautifulSoup(bk.getmetadataxml(), 'lxml')
    if metadata_soup.find('dc:title'):
        dc_title = metadata_soup.find('dc:title').string
    epub_path = os.path.join(output_dir, cleanup_file_name(dc_title) + '_epub2.epub')

    # zip up everything
    try:
        epub_zip_up_book_contents(temp_dir, epub_path)
        print('epub2 book copied to: ' + epub_path)
        shutil.rmtree(temp_dir)
    except:
        print('File couldn\'t be copied to: ' + epub_path)
        shutil.rmtree(temp_dir)
        return -1

    return 0

def main():
    print('I reached main when I should not have\n')
    return -1

if __name__ == "__main__":
    sys.exit(main())
