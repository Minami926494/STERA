#!/usr/bin/env python
# -*- coding: utf-8 -*-
from re import sub, finditer, findall, escape, split
from regrex_core import reg
from sys import exit


# 文件读写
class file:
    def __init__(self, file_type, print_str=None):
        self.href, self.page, self.check, self.print = file_type, '\n'.join((''.join(('<page id="', i, '" href="', sub(r'.*/', '', self.bk.id_to_href(
            i)), '">\n', sub(r'(?:\r\n|(?<![\r\n])\r(?![\r\n]))', '\n', self.bk.readfile(i)).expandtabs(1), '\n</page>')) for i in file_type)), [], print_str

    def __call__(self, *flow_path):
        for i in flow_path:
            if isinstance(i, tuple):
                self.page = reg(self.page, i)
            else:
                chk = set()
                for j in finditer(i, self.page):
                    j = findall(''.join(
                        ('<page id="(.*?)".*?>(?:(?!</page>)[\\s\\S])*?', escape(j.group(0)))), self.page)
                    for k in j:
                        chk.add(k)
                self.check.append(chk)
        return self

    def __iter__(self):
        return iter(self.check)

    def __del__(self):
        pgs, h = split(r'\s*</page>\s*', sub(r'\s*<page.*?>\s*',
                       '', self.page)), len(self.href)
        for i in range(h):
            self.bk.writefile(self.href[i], pgs[i])
        if self.print:
            print(self.print)

    @classmethod
    def dim(cls, bk):
        cls.bk = bk


if __name__ == "__main__":
    print('程序运行环境异常！')
    exit(-1)
