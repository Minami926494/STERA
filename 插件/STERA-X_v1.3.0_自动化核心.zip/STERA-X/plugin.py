#!/usr/bin/env python
# -*- coding: utf-8 -*-
from re import sub, search
from main import file
from launch_groups import *
from sys import exit


# 需保留的样式表
STYLE = {'style.css', 'default.css'}

# 需写入的XML
XML = {'META-INF/com.apple.ibooks.display-options.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<display_options>\n<platform name="*">\n<option name="specified-fonts">true</option>\n</platform>\n</display_options>',
       'META-INF/zhangyue-expansion.xml': '<?xml version="1.0" encoding="UTF-8"?>\n<zhangyue-expansion version="3.4.2">\n<book_id></book_id>\n</zhangyue-expansion>'}

# 需保留的杂项
EX = {'mimetype', 'META-INF/container.xml'}


def inner(tag, pg):
    return search('([\\s\\S]*?)'.join((tag.join(('<pre id="', '">')), '</pre>')), pg).group(1).strip()


def rpk(pk):
    return tuple(i[0] for i in pk)


def id2href(id, bk):
    return bk.id_to_href(id).rsplit('/', 1)[-1]


def bpg(bsn, data, bk):
    if bsn in rpk(bk.text_iter()):
        bk.writefile(bsn, data)
        print(id2href(bsn).join(('　-已存在：【', '】')))
    else:
        bk.addfile(bsn, ''.join((bsn, '.xhtml')), data)
        print(id2href(bsn).join(('　+生成：【', '】')))


def run(bk):
    # 检查EPUB是否符合规范
    if bk.epub_is_standard() and bk.epub_version() == '3.0':
        print('虚空文学旅团STERAePub++ ver1.3.0')
    else:
        print('此文件不是规范的EPUB3文件！')
        return -1

    # 传入bk参数，预定义文件类型与默认值
    file.dim(bk)
    id2href.__defaults__, bpg.__defaults__ = (None, bk), (None, None, bk)
    Bool, XH, CSS, IMG, OTHER, NAV, COVER, PIC, DEL = 0, rpk(bk.text_iter()), rpk(
        bk.css_iter()), rpk(bk.image_iter()), bk._w.other, None, None, set(), set()

    # 填充信息采集
    print('\n填充信息采集……')
    if 'info.xhtml' in XH:
        info = bk.readfile('info.xhtml')
        inner.__defaults__ = None, info
        summary, name, subtitle, volume, isbn, writer, painter, translator, introducer, inputer, epuber = sub(r'(\r\n|(?<![\r\n])\n(?![\r\n])|(?<![\r\n])\r(?![\r\n])){2,}', r'\1<p><br/></p>\1', sub(r'([\n\r]+)', r'</p>\1<p>', inner(
            'summary')).join(('<p>', '</p>'))), inner('name'), inner('subtitle'), inner('volume'), inner('isbn'), inner('writer'), inner('painter'), inner('translator'), inner('introducer'), inner('inputer'), inner('epuber')
        print('　+信息采集完成，删除【info.xhtml】')
        bk.deletefile('info.xhtml')
        tit, XH = subtitle.join(('～', '～')).join((name, volume)).strip(
        ) if subtitle and subtitle != '副標題' else ' '.join((name, volume)).strip(), rpk(bk.text_iter())
    else:
        print('　-未采集到有效信息')
        summary, name, subtitle, volume, isbn, writer, painter, translator, introducer, inputer, epuber, tit = '<p>簡介</p>', '系列名', '副標題', '卷號', 'ISBN', '作家', '畫師', '譯者', '圖源', '錄入', 'EPUB', '標題'

    # 覆写OPF文档
    print('\n覆写OPF文档……')
    bk.setmetadataxml('\n'.join((isbn.join(('<dc:identifier id="BookId">urn:isbn:', '</dc:identifier>')), tit.join(('<dc:title id="title">', '</dc:title>')), writer.join(('<dc:creator id="create">', '</dc:creator>')), epuber.join(('<dc:contributor>', '</dc:contributor>')),
                      '<meta property="file-as" refines="#create">明日✿咲葉</meta>\n<dc:subject>lightnovel</dc:subject>\n<dc:rights>voidlord</dc:rights>\n<dc:language>zh-CN</dc:language>\n<meta property="ibooks:specified-fonts">true</meta>\n<meta property="ibooks:binding">true</meta>\n<dc:identifier id="duokan-book-id">none</dc:identifier>\n<meta property="opf:scheme" refines="#duokan-book-id">DKID</meta>\n<dc:identifier id="zhangyue-book-id">none</dc:identifier>\n<meta property="opf:scheme" refines="#zhangyue-book-id">ZYID</meta>\n<meta name="cover" content="cover.jpg"/>')).join(('\n<metadata xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:opf="http://www.idpf.org/2007/opf">\n', '\n</metadata>\n')))
    bk.setpackagetag(
        '<package version="3.0" unique-identifier="BookId" prefix="rendition: http://www.idpf.org/vocab/rendition/#" xmlns="http://www.idpf.org/2007/opf">')
    for i in bk.manifest_epub3_iter():
        if i[3] == 'nav':
            NAV = i[0], i[1].rsplit('/', 1)[-1]
        elif i[0] in XH:
            bk.set_manifest_epub3_attributes(i[0], 'scripted')
        elif (i[0] == 'cover' or i[0] == 'cover.jpg' or i[0] == 'cover.webp') and i[0] in IMG:
            bk.set_manifest_epub3_attributes(i[0], 'cover-image')
        else:
            bk.set_manifest_epub3_attributes(i[0], None)
    print(''.join(('　+【', bk.get_opfbookpath(), '】重构完成，检测到【',
          NAV[1], '】'))) if NAV else print(bk.get_opfbookpath().join(('　-【', '】中未检测到NAV文档')))

    # 文件增删
    print('\n添加XML至META-INF……')
    for i in XML:
        if i not in OTHER:
            print(i.join(('　+生成：【', '】')))
            bk.addotherfile(i, XML[i])
        else:
            print(i.join(('　-已存在：【', '】')))
    print('\n删除多余样式表……')
    for i in CSS:
        if i not in STYLE:
            print(id2href(i).join(('　+删除：【', '】')))
            bk.deletefile(i)
            Bool = 1
    Bool = 0 if Bool else print('　-无多余样式表')
    print('\n删除不存在OPF内的文件……')
    for i in OTHER:
        if i not in EX and i not in XML and '.opf' not in i:
            print(i.join(('　+删除：【', '】')))
            bk.deleteotherfile(i)
            Bool = 1
    Bool = 0 if Bool else print('　-无多余杂项文件')

    # 文件编辑
    for i in file(XH, '\n删除多余书籍页并获取图片页……')(XH_class, XH_tag, XH_text, XH_title, XH_note, XH_image, XH_page, r'(?i)(?:<title></title>|colophon|bookwalker[^"\n]*?\.|kobo[^"\n]*?\.)', '<title>封面</title>', '<title>插圖</title>', '<h3 class="ctt">Contents</h3>'):
        if not Bool:
            Bool = 1
            for j in i:
                if j and j != NAV[0]:
                    print(id2href(j).join(('　+删除：【', '】')))
                    bk.deletefile(j)
                    DEL.add(j)
        elif Bool == 1:
            Bool = 2
            for j in i:
                if j and j not in DEL:
                    print(id2href(j).join(('　+捕获封面页：【', '】')))
                    COVER = j
        elif Bool == 2:
            Bool = 3
            for j in i:
                if j and j not in DEL:
                    print(id2href(j).join(('　+捕获插图页：【', '】')))
                    PIC.add(j)
        else:
            for j in i:
                if j and j not in DEL:
                    print('\n重构NAV文档……')
                    TOC = ''.join(('<?xml version="1.0" encoding="utf-8" standalone="no"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN" xmlns:epub="http://www.idpf.org/2007/ops" xmlns:xml="http://www.w3.org/XML/1998/namespace">\n<head>\n<title>導航</title>\n<link href="../Styles/style.css" type="text/css" rel="stylesheet"/>\n<script type="text/javascript" src="../Misc/script.js"></script>\n</head>\n<body epub:type="frontmatter" id="nav">\n<nav epub:type="toc" id="toc" role="doc-toc">\n<ol>\n<li><a href="', id2href(COVER), '">封面</a></li>\n<li><a href="title.xhtml">標題</a></li>\n<li><a href="message.xhtml">製作信息</a></li>\n<li><a href="summary.xhtml">簡介</a></li>\n<li><a href="',
                                  id2href(j), '">目錄</a></li>', sub(r'(<a.*?/a>)', r'<li>\1</li>', sub(r'(?:<p( )class="ctit">|</?p>)', r'\1', sub(r'(?:<div.*?>\s*|\s*</div>)', '', sub(r'<div class="part">((?:(?!</div>)[\s\S])*?)</div>', r'<ol>\1</ol>', search(r'<h3 class="ctt">.*?</h3>([\s\S]*)(?=</body>)', bk.readfile(j)).group(1))))), '</ol>\n</nav>\n<nav epub:type="landmarks" id="landmarks" hidden="">\n<ol>\n<li><a epub:type="cover" href="', id2href(COVER), '">封面</a></li>\n<li><a epub:type="toc" href="', id2href(j), '">目錄</a></li>\n</ol>\n</nav>\n</body>\n</html>'))
                    if NAV:
                        print(NAV[1].join(('　+重构：【', '】')))
                        bk.writefile(NAV[0], TOC)
                        NAV = NAV[0]
                    else:
                        print('　+生成：【navigation.html】')
                        bk.addfile('navigation', 'navigation.html', TOC)
                        bk.set_manifest_epub3_attributes('navigation', 'nav')
                        NAV = 'navigation'

    # 生成信息页
    print('\n生成信息页……')
    bpg('message', ''.join(('<div class="message">\n<div>\n<div class="meg">\n<p>製 作 信 息</p>\n</div>\n<div class="meghr"/>\n<div class="creator">\n<p>作者</p>\n</div>\n<div>\n<p>', writer, '</p>\n</div>\n<div class="creator">\n<p>插畫</p>\n</div>\n<div>\n<p>', painter, '</p>\n</div>\n<div class="creator">\n<p>譯者</p>\n</div>\n<div>\n<p>', translator, '</p>\n</div>\n<div class="creator">\n<p>圖源</p>\n</div>\n<div>\n<p>', introducer, '</p>\n</div>\n<div class="creator">\n<p>錄入</p>\n</div>\n<div>\n<p>', inputer,
        '</p>\n</div>\n<div class="group">\n<p><a href="https://www.lightnovel.us">輕之國度錄入組</a>×<a href="https://www.voidlord.com">虛空文學旅團</a></p>\n</div>\n<div class="logo">\n<img alt="logo" src="../Images/logo.png"/>\n</div>\n</div>\n</div>')).join(('<?xml version="1.0" encoding="utf-8" standalone="no"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN" xmlns:epub="http://www.idpf.org/2007/ops" xmlns:xml="http://www.w3.org/XML/1998/namespace">\n<head>\n<title>製作信息</title>\n<link href="../Styles/style.css" type="text/css" rel="stylesheet"/>\n<script type="text/javascript" src="../Misc/script.js"></script>\n</head>\n<body>\n', '\n</body>\n</html>')))
    bpg('summary', summary.join(('<?xml version="1.0" encoding="utf-8" standalone="no"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN" xmlns:epub="http://www.idpf.org/2007/ops" xmlns:xml="http://www.w3.org/XML/1998/namespace">\n<head>\n<title>簡介</title>\n<link href="../Styles/style.css" type="text/css" rel="stylesheet"/>\n<script type="text/javascript" src="../Misc/script.js"></script>\n</head>\n<body>\n<div class="summary">\n<h3>簡介</h3>\n<hr/>\n', '\n</div>\n</body>\n</html>')))
    bpg('title', ''.join(('<div class="title">\n<div class="center" style="margin:4em auto 0;">\n<p class="tilh em18 bold">', name, '</p>\n', subtitle.join(('<p class="tilh em09 bold" style="margin:1em 0 0;">～', '～</p>\n')) if subtitle and subtitle != '副標題' else '', '</div>\n<div class="center" style="margin:3em auto 4em;">\n<p class="tilh em15 bold">', volume, '</p>\n</div>\n<div class="center">\n<p class="tilh em07 bold">作者</p>\n<p class="tilh em11 bold" style="margin:0.2em 0 0.75em;">', writer,
        '</p>\n<p class="tilh em07 bold">插畫</p>\n<p class="tilh bold" style="margin:0.15em 0 0;">', painter, '</p>\n</div>\n</div>')).join(('<?xml version="1.0" encoding="utf-8" standalone="no"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN" xmlns:epub="http://www.idpf.org/2007/ops" xmlns:xml="http://www.w3.org/XML/1998/namespace">\n<head>\n<title>標題</title>\n<link href="../Styles/style.css" type="text/css" rel="stylesheet"/>\n<script type="text/javascript" src="../Misc/script.js"></script>\n</head>\n<body>\n', '\n</body>\n</html>')))

   # 重组SPINE序列
    print('\n重组SPINE序列……')
    bk.setspine_ppd('ltr')
    SPINE, LINEAR, PROP, PART = list(rpk(bk.getspine())), [], [], {
        COVER: 0, 'title': 1, 'message': 2, 'summary': 3}
    if NAV in SPINE:
        SPINE.remove(NAV)
    for i in bk.text_iter():
        i = i[0]
        if i != COVER and i != 'title' and i != 'message' and i != 'summary' and i != NAV:
            if i in SPINE:
                PART[i] = (SPINE.index(i)+1)*1000
            else:
                SPINE.append(i)
                s = i.rsplit('_part', 1)
                PART[i] = (SPINE.index(s[0])+1)*1000+int(s[1])
    SPINE.extend(['title', 'message', 'summary'])
    SPINE.sort(key=lambda x: PART[x])
    SPINE.append(NAV)
    for i in SPINE:
        if i:
            LINEAR.append('no') if i == NAV else LINEAR.append('yes')
            if i == COVER:
                PROP.append('duokan-page-fullscreen')
            elif i in PIC:
                PROP.append('duokan-page-fitwindow')
            else:
                PROP.append(None)
        else:
            SPINE.remove(i)
    bk.setspine_epub3(list(zip(SPINE, LINEAR, PROP)))
    print('　+SPINE重组完成')
    return 0


if __name__ == "__main__":
    print('程序运行环境异常！')
    exit(-1)
