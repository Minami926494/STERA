#!/usr/bin/env python
# -*- coding: utf-8 -*-
from re import compile, subn, finditer
from sys import exit


# 跨页二级正则
def reg(aim, launch_group):
    if launch_group[0]:
        print(launch_group[0].join(('\n', '……')))
    pre = launch_group[1].replace('^^', '(?<![^\\n])').replace(
        '$$', '(?![^\\n])') if launch_group[1] else None
    for s in launch_group[2:]:
        if pre:
            r, pg = 0, [i.group(0) for i in finditer(pre, aim)]
            p = range(len(pg))
            for g in p:
                part = pg[g]
                aim = aim.split(part, 1)
                part, _r = rex(part, s)
                pg[g], aim = ''.join((aim[0], part)), aim[1]
                r += _r
            pg[-1] = ''.join((pg[-1], aim))
            aim = ''.join(pg)
            print(''.join(('　+替换', str(r), '项：【',
                           s[0], '】'))) if r else print(s[0].join(('　-未匹配到：【', '】')))
        else:
            aim, r = rex(aim, s)
            print(''.join(('　+替换', str(r), '项：【',
                  s[0], '】'))) if r else print(s[0].join(('　-未匹配到：【',  '】')))
    return aim


# 无穷计数正则
def rex(pg, dic):
    ti, d = 0, dic[1]
    for m in d:
        m, r, t = m.replace('^^', '(?<![^\\n])').replace(
            '$$', '(?![^\\n])'), d[m], 0
        if '(*' == m[:2]:
            e, x = m.find(')'), 1
            m, n = compile(m[e+1:]), int(m[2:e]) if e > 2 else 0
            while x <= n or n == 0:
                pg, _t = subn(m, r.replace('*', str(x).zfill(3)), pg)
                if _t:
                    t += _t
                    x += 1
                else:
                    break
        else:
            pg, t = subn(m, r, pg)
        ti += t
    return pg, ti


if __name__ == "__main__":
    print('程序运行环境异常！')
    exit(-1)
