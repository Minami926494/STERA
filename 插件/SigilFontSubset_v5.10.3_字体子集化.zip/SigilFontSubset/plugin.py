#!/usr/bin/env python3
# -*- coding: utf-8 -*-
##################################################################
#相关参考https://fonttools.readthedocs.io/en/latest/developer.html
##################################################################
import os,re,shutil,tempfile,collections,time
from os import path,chdir
import html.entities,urllib
from unicodedata import decimal
from re_compiled import RE_COMPILE,RE_CLEAN,RE_SEL_MATCH
from contextlib import contextmanager
from fontTools import subset
from fontTools.ttLib import TTFont
from xml.etree import cElementTree
try:
    from epubtools.EpubWrapper import EpubBook
except:
    pass

#字体-文本映射表
FONT_MAPPINGS = {} # { manifest_id : [chars , loss_chars] }
FONT_DIC = {} # { manifest_id : origin_font_path}
LWCASE_BOOKPATH_TO_ID = {} # { lowercase_bookpath : manifest_id } 
ID_TO_BOOKPATH = {} # { manifest_id : bookpath }
CMAP = {}

HTML_ENTITY = html.entities.name2codepoint.copy()
for name in ["amp","lt","gt"]:
    del HTML_ENTITY[name]

#CssObject类集合了一个html所指定css属性及其选择器
class CssObject:

    def __init__(self,css_text):
        self.fontfamily_to_id = {} # { font_family_name : manifest_id , ... }
        self.font_selectors = collections.OrderedDict() # { selector_str : [font_series] , ... }
        self.list_selectors = collections.OrderedDict() # { selector_str : list_style_type }
        self.__reference_path = ""
        css_text = self.make_family_dict(css_text)
        self.get_font_selector(css_text)
        self.get_listtype_dict(css_text)
        chdir(path.dirname(__file__))
    #设置 font-family => manifest_id 映射
    def make_family_dict(self,css_text):
        def func_(match_):
            #字体文件名筛选规则：
            if match_.group().startswith('^|'): #读到css_text中的文件路径
                self.__reference_path = match_.group(2)[2:-2] #设读到的文件路径为参考路径
            
            elif RE_COMPILE["src:url"].match(match_.group(1)): #读到@font-face内容
                font_family = find_attr_not_covered('font-family',match_.group(1),low = True)
                font_src = find_attr_not_covered('src',match_.group(1))
                font_urls = RE_COMPILE['findall-url'].findall(font_src)
                if not font_urls:
                    return ''
                chdir(self.__reference_path)
                for font_url in font_urls:
                    font_url_decoded = urllib.parse.unquote(font_url) #将URL编码转化为unicode码（Sigil可能将部分url链接的中文转化为URL码）
                    if path.exists(font_url_decoded):
                        font_abspath = path.abspath(font_url_decoded)
                        font_bookpath = path.relpath(font_abspath,EBOOK_ROOT).replace('\\','/')
                        manifest_id = LWCASE_BOOKPATH_TO_ID[font_bookpath.lower()]
                        if manifest_id:
                            self.fontfamily_to_id[font_family] = manifest_id
                            break
            return ''
        css_text = RE_COMPILE["@font-face"].sub(func_,css_text)
        return css_text

    #寻找所有带font-family设置的CSS选择器，如果font-family对应的字体存在于mainifest中，则该选择器入列。
    def get_font_selector(self,css_text):
        order = 0
        selectors_list = []
        # "sel-fseri" : r'([\w\.\*\[#!][^{}/;]*?)({[^{}]*?font-family[^{}]*?})'
        for selector_str,font_serif_str in RE_COMPILE['sel-fseri'].findall(css_text):
            font_serif = find_attr_not_covered('font-family',font_serif_str,low=True)
            if font_serif == '':
                continue
            important = 0
            if font_serif[0] == "!":
                font_serif = font_serif[1:] #去除"!"号标志
                important = 1
            valid_font_serif = []
            for font_name in font_serif.split(','):
                if font_name == "inherit":
                    valid_font_serif = ["inherit"]
                    break
                if font_name in self.fontfamily_to_id.keys():
                    valid_font_serif.append(font_name)
            #if valid_font_serif != []: #20220601修改，运行有效字体List为空。修复无视节点外部字体属性的问题。
            for selector in selector_str.split(','):
                if important == 1 :
                    #带!important属性的字体设置，其选择器字符串前加"^"号标志
                    selectors_list.append(['^'+selector,valid_font_serif,order])
                else:
                    selectors_list.append([selector,valid_font_serif,order])        
            order += 1
        return self.sort_font_selector(selectors_list)

    #设置css选择器集合并依其优先级别排序
    def sort_font_selector(self,selectors_list):
        for slist_item in selectors_list:
            p = self.priority(slist_item[0],slist_item[2]) #计算优先级别
            slist_item.append(p)
            if slist_item[0][0] == '^':
                slist_item[0] = slist_item[0][1:] #去除"^"号标志
        selectors_list.sort(key = lambda x:x[3] , reverse = True)
        for sel,font_serif,order,prior in selectors_list:
            if self.font_selectors.get(sel):
            # 防止同名选择器同属性前序覆盖后续(后序权值大，处于选择器列表顺序优先，会先赋值。)
                continue
            self.font_selectors[sel] = font_serif

    # 寻找所有带 list-style / list-style-type 设置的CSS选择器，初始化。
    def get_listtype_dict(self,css_text):
        order = 0
        selectors_list = []
        for selector_str,selector_content in RE_COMPILE['sel-liststyle'].findall(css_text):
            list_type_str = find_attr_not_covered("list-style",selector_content)
            if list_type_str == "":
                continue
            important = 0
            if list_type_str[0] == "!":
                list_type = list_type_str[1:] #去除"!"号标志
                important = 1
            valid_value = ""
            for value in list_type_str.strip().split(" "):
                if value in ["none","disc","circle","square","decimal",
                             "lower-roman","upper-roman","lower-alpha","upper-alpha",
                             "lower-greek","cjk-ideographic","decimal-leading-zero","lower-latin","upper-latin"]:
                    valid_value = value
            if valid_value != "":
                for selector in selector_str.split(','):
                    if important == 1:
                        selectors_list.append(["^"+selector,valid_value,order])
                    else:
                        selectors_list.append([selector,valid_value,order])
            order += 1
        return self.sort_list_selector(selectors_list)

    #设置css选择器集合并依其优先级别排序
    def sort_list_selector(self,selectors_list):
        for slist_item in selectors_list:
            p = self.priority(slist_item[0],slist_item[2]) #计算优先级别
            slist_item.append(p)
            if slist_item[0][0] == '^':
                slist_item[0] = slist_item[0][1:] #去除"^"号标志
        selectors_list.sort(key = lambda x:x[3] , reverse = True)
        for sel,list_type,order,prior in selectors_list:
            if self.list_selectors.get(sel):
            # 防止同名选择器同属性前序覆盖后续(后序权值大，处于选择器列表顺序优先，会先赋值。)
                continue
            self.list_selectors[sel] = list_type

     #CSS选择器优先级别计算
    def priority(self,selectorKey,order):
        p = [0,0,0,0,0,0,0]  #[!important , 内联style, ID , 类、属性 , 元素 , 通配符 , 选择器顺序 ]
        p[6] = order
        if '!style' in selectorKey: #内联style
            p[1] = 1
        else:
            n = re.subn(r'\[.*?\]','',selectorKey) #属性选择器
            p[3] += n[1] 
            n = re.subn(r'[#][-\w]+','',n[0]) #ID选择器
            p[2] += n[1]
            n = re.subn(r'[.][-\w]+','',n[0]) #类选择器
            p[3] += n[1] 
            n = re.subn(r'[\w-]+','',n[0]) #元素选择器
            p[4] += n[1]
            n = re.subn(r'\*','',n[0]) #通配符选择器
            p[5] += n[1]
        if selectorKey[0] == '^': # !important属性
            p[0] = 1
        return p

#计算可引用的相对路径集（包含从最短到最长的相对路径）
def get_all_relativepath(from_path,to_path,low = False):
    all_relativepath = []
    shortest = book.get_relativepath(from_path,to_path) #计算最短相对路径
    if low:
        shortest = shortest.lower()
    all_relativepath.append(shortest)
    temp = re.match(r'(\.\./)*',shortest)
    pre_back = int(len(temp.group())/3) if temp else 0 # 计算最短相对路径的后退级数
    back = 0
    back_dir = path.dirname(from_path)
    while back_dir:
        back += 1
        if back > pre_back: #当后退级数超过最短相对路径的后退级数，开始计算相对路径
            rpath = book.get_relativepath(back_dir,to_path)
            rpath = '../'*back + rpath
            if low:
                rpath = rpath.lower()
            all_relativepath.append(rpath)
        back_dir = path.dirname(back_dir)
    return all_relativepath

#将CSS多余的空符去除
def de_blank(text):
    quotation_content = RE_CLEAN['quo_cont'].findall(text)
    result = RE_CLEAN['blank'].sub(r' ',text)
    result = RE_CLEAN['sp_symbols'].sub(r'\1',result)
    result = RE_CLEAN['sp_sym_plus'].sub(r'\1',result)
    if quotation_content:
        result = RE_CLEAN['quo_cont'].sub(lambda x:quotation_content.pop(0),result)
    return result

#检测文档<head>所包含的link链接、<style>或内联style
#html文档清除注释
def pretreatment(html):
    instyle_list = []
    sN = [0]
    def in_style_pre(match):
        font,list = '',""
        font = find_attr_not_covered('font-family',match.group(2),low = True)
        list = find_attr_not_covered('list-style',match.group(2),low = True)
        if not font and not list:
            return match.group()
        else:
            sN[0] += 1
            style_str = '!style' + str(sN[0]) + '{'
            if font:
                style_str += 'font-family:' + font + ';'
            if list:
                style_str += 'list-style:' + list + ';'
            style_str += "}"
            instyle_list.append(style_str)
            #将含font-family设置的内联style转为fstyle属性
            return re.sub(r'style[\r\n\t ]*=[\r\n\t ]*([\"\'])[^>=]*?\1','fstyle="!style'+str(sN[0])+'"',match.group()) 
    html = RE_CLEAN["html_notes"].sub('',html)
    html = RE_CLEAN['xml-doctype'].sub('',html,2)
    html = RE_CLEAN["change-xmlns"].sub(r"\1_xmlns\2",html)
    head = RE_CLEAN["search_head"].search(html)
    head = head.group() if head else ''
    head = RE_COMPILE['css_notes'].sub(r'',head)
    css_list = RE_CLEAN['link_or_style'].findall(head)
    html = RE_CLEAN['in_style_pre'].sub(in_style_pre,html)
    html = decode_xml_entities(html)
    return css_list+instyle_list,html

#将文档所应用的所有CSS整合成一个文件
def integrate_css_text(css_list,current_bookpath):
    # current_bookpath 当前xhtml路径，引入这个变量为了方便之后计算相对路径有效性
    curdir = path.join(EBOOK_ROOT,path.dirname(current_bookpath))
    chdir(curdir) #设置当前目录
    def import_css_convert(match,cur_dir,ignore = []):
        # ignore 储存一组可忽略的css_bookpath,防止互导入造成死循环
        # cur_dir 当前处理的css路径，引入这个变量为了方便之后计算相对路径有效性
        chdir(cur_dir)
        _css_text = ""
        # work_bookpath用于计算相对路径，css_bookpath若为空，则意味着@import位置在当前html而非css文件。
        if match.group(4):
            import_url = match.group(4) #捕获所引用的路径
            if path.exists(import_url):
                css_abspath = path.abspath(import_url)
                url_bookpath = path.relpath(css_abspath,EBOOK_ROOT).replace('\\','/')
                if url_bookpath in ignore:
                    return _css_text
                url_css_id = LWCASE_BOOKPATH_TO_ID[url_bookpath.lower()]
                if url_css_id:
                    ignore.append(url_bookpath)
                    css_dir = path.dirname(css_abspath)
                    _css_text += "^|"+css_dir+"|$"
                    _css_text += book.readfile(url_css_id)
                    _css_text = RE_COMPILE['css_notes'].sub(r'',_css_text)
                    _css_text = RE_COMPILE["@import"].sub(lambda match:import_css_convert(match,css_dir,ignore),_css_text)
                    _css_text += "^|"+cur_dir+"|$"
        return _css_text
    css_text = ""
    html_bookpath_added = [False] #表示是否已在css_text中添加当前文本的地址
    for css_link in css_list:
        t = RE_COMPILE['link'].search(css_link)#将link导入CSS代码替换成对应CSS文本
        if t != None:
            link_href = t.group(2)
            if path.exists(link_href):
                css_abspath = path.abspath(link_href)
                css_bookpath = path.relpath(css_abspath,EBOOK_ROOT).replace('\\','/')
                css_id = LWCASE_BOOKPATH_TO_ID[css_bookpath.lower()]
                if css_id:
                    css_dir = path.dirname(css_abspath)
                    css_text += "^|"+css_dir+"|$"
                    css_text += book.readfile(css_id)
                    css_text = RE_COMPILE["@import"].sub(lambda match:import_css_convert(match,css_dir,[css_bookpath]),css_text)
                    html_bookpath_added[0] = False
            continue
        #将<style>代码整合进CSS文本
        t = RE_COMPILE['style'].search(css_link)
        if t != None:
            if not html_bookpath_added[0]:
                css_text += "^|"+curdir+"|$"
                html_bookpath_added[0] = True
            css_text += t.group(1)
            css_text = RE_COMPILE["@import"].sub(lambda match:import_css_convert(match,curdir),css_text)
            continue
        t = RE_COMPILE['in_style'].search(css_link)
        if t != None:
            if not html_bookpath_added[0]:
                css_text += "^|"+curdir+"|$"
                html_bookpath_added[0] = True
            css_text += t.group(0)
            continue
    css_text = RE_COMPILE['css_notes'].sub(r'',css_text)
    css_text = de_blank(css_text)
    return css_text

#寻找同一个CSS选择器内部覆盖层次最顶层的属性
def find_attr_not_covered(attr_str,text,low = False):
    result = RE_COMPILE[attr_str+'-!'].findall(text)
    if result != []:
        #带!important属性的字体，前面加"!"号标志
        result = '!' + re.sub(r'[\'\"]',r'',result.pop(-1))
        if low:
            return result.lower()
        return result
    result = RE_COMPILE[attr_str].findall(text)
    if result != []:
        result = re.sub(r'[\'\"]',r'',result.pop(-1))
        if low:
            return result.lower()
        return result
    return ''

#对CSS选择器进行解析并判断节点所对应CSS选择器，暂不支持兄弟选择器、伪类、伪元素
def selector_match(node,sel):
    def match(node,local,name,attr_value,attr_name):#元素、ID、类选择器所用的匹配规则
        if not attr_value and name: 
            if node.tag == name or name == '*':
                return node
            elif local != True:
                parent_node = PARENT_MAP[node]
                if parent_node != None:
                    return match(parent_node,local,name,attr_value,attr_name)
            return None
        if attr_value and not name:
            if node.attrib and attr_name in node.attrib.keys():
                S = node.attrib[attr_name].split(' ')
            else:
                S = []
            if S and attr_value in S:
                return node
            elif local != True:
                parent_node = PARENT_MAP[node]
                if parent_node != None:
                    return match(parent_node,local,name,attr_value,attr_name)
        return None
    def em_selector(node,index,index_,sel,local):#元素选择器所用的解析规则
        name = sel[-index+1:-index_]
        node = match(node,local,name,'','')
        if node != None:
            local = False
            if sel[-index] == '>':
                node = PARENT_MAP[node]
                local,index_ = True,index
                return node,index,index_,local
            else :
                node = PARENT_MAP[node]
                index_ = index
                return node,index,index_,local
        return None,0,0,False
    def id_class_selector(node,index,index_,sel,local):#ID、类选择器所用的解析规则
        attr_value = sel[-index+1:-index_]
        if sel[-index] == '.':
            node = match(node,local,'',attr_value,'class')
        else:
            node = match(node,local,'',attr_value,'id')
        if node != None:
            local = False
            if index < len(sel):
                if sel[-index-1] in [' ','>']:
                    node = PARENT_MAP[node]
                    index,index_ = index + 1,index + 1
                    if sel[-index-1] == '>':
                        local = True
                    return node,index,index_,local
                elif sel[-index-1] in ['+','~']:
                    return None,0,0,False
                else:
                    local,index_ = True,index
                    return node,index,index_,local
            elif index == len(sel):
                return node,index,index_,local
        return None,0,0,False
    def attr_selector(node,index,index_,sel,local):#I属性选择器所用的解析规则
        def attr_match(node,local,operator,attr_name,value):#属性选择器所用的匹配规则
            if operator in ['','=','*=','^=','$=','|=','~=']:
                if node.attrib and attr_name in node.attrib.keys():
                    S = node.attrib[attr_name]
                else:
                    S = ''
                if S:
                    if operator == '':
                        return node
                    if operator == '=' and value == S:
                        return node
                    if operator == '*=' and value in S:
                        return node
                    if operator == '^=' and re.match(value,S):
                        return node
                    if operator == '$=' and re.search(value+r'$',S):
                        return node
                    if operator == '|=' and re.match(value+'-',S):
                        return node
                    if operator == '~=' and re.search(r'\b'+value+r'\b',S):
                        return node
                elif not local:
                    parent_node = PARENT_MAP[node]
                    if parent_node:
                        node = attr_match(parent_node,local,operator,attr_name,value)
                        return node
            return None
        value_str = sel[-index+1:-index_-1]

        value_str = RE_SEL_MATCH['value_str'].sub(r'',value_str)
        attr_name = RE_SEL_MATCH['attr_name'].split(value_str)

        if len(attr_name) == 1: #无操作符
            attr_name = attr_name.pop(0)
            operator = value = ''
        else: #有操作符
            attr_name = attr_name.pop(0)
            value = RE_SEL_MATCH['value'].split(value_str).pop(-1)
            operator = RE_SEL_MATCH['operator'].search(value_str).group(1)
            

        node = attr_match(node,local,operator,attr_name,value)
        if node != None:
            local = False
            if index < len(sel):
                if sel[-index-1] in [' ','>']:
                    node = PARENT_MAP[node]
                    index,index_ = index + 1,index + 1
                    if sel[-index-1] == '>':
                        local = True
                    return node,index,index_,local
                elif sel[-index-1] in ['+','~']:
                    return None,0,0,False 
                else:
                    local,index_ = True,index
                    return node,index,index_,local
            elif index == len(sel):
                return node,index,index_,local
        return None,0,0,False

    index = 0
    index_ = 1
    local = True
    sel += "$" 
    Len = len(sel)
    # sel 以"$" 符号结尾，并不等于选择器字符串值
    # 因此做等效匹配用 in 而不是 == 号。
    if "!style" in sel:
        if node.attrib and 'fstyle' in node.attrib.keys():
            if node.attrib['fstyle'] in sel:
                return True

    while index < Len:
        index += 1
        if sel[-index] in [' ','>','+','~','.','#','[']:
            if sel[-index] in [' ','>']: 
                node,index,index_,local = em_selector(node,index,index_,sel,local)
                if node != None:
                    continue
                return False
            if sel[-index] in ['.','#']: 
                node,index,index_,local = id_class_selector(node,index,index_,sel,local)
                if node != None:
                    if index == Len:
                        return True
                    continue
                return False
            if sel[-index] in ['[']:
                node,index,index_,local = attr_selector(node,index,index_,sel,local)
                if node != None:
                    if index == Len:
                        return True
                    continue
                return False
            if sel[-index] in ['+','~']: #暂不支持兄弟选择器
                if sel[-index+1] == '=':
                    continue
                return False
        if index == Len:
            name = sel[-index:-index_]
            node = match(node,local,name,'','')
            if node != None:
                return True
    return False

def decode_xml_entities(text):
    def fix(m):
        c = m.group(1)
        if c in HTML_ENTITY:
            return chr(HTML_ENTITY[c])
        else:
            if c[0] == "#" and len(c) > 1:
                # numeric
                if c[1] == "x" and len(c) > 2:
                    try:
                        i = int(c[2:], 16)
                        return chr(i)
                    except:
                        # error
                        return ''
                else:
                    try:
                        i = int(c[1:])
                        return chr(i)
                    except:
                        # error
                        return ''
            # error!
            return m.group()
    return re.sub(r">[^>]*<",lambda m:re.sub(r"&([#a-zA-Z0-9]+);",fix,m.group()),text)

#清除重复字符
def filter_string(s):
    mytext = "".join(set(s))
    return mytext


def make_font_mappings(manifest_id,text):
    text = RE_CLEAN['chars_blank'].sub('',text)
    text = filter_string(text) #清除重复字符
    new_chars = ""
    loss = ""
    #检测该字符是否存在于FontMappings
    for ch in text:
        if ch not in FONT_MAPPINGS[manifest_id][0]:
            new_chars += ch
    #检测该字符是否存在于字体文件中
    for ch in new_chars:
        if ord(ch) in CMAP[manifest_id]:
            FONT_MAPPINGS[manifest_id][0] += ch
        else:
            loss += ch
    # 20220608 修改遗漏字符提醒规则
    '''
    for ch in loss:
        if ch not in FONT_MAPPINGS[manifest_id][1]:
            FONT_MAPPINGS[manifest_id][1] += ch
    '''
    return loss

# 获取有序li节点的序号字符串
def turn_order(list_order,list_type):
    if list_type == "decimal": # arab数字
        return str(list_order)
    elif list_type == "decimal-leading-zero": #补零arab数字
        if list_order < 10:
            return "0" + str(list_order)
        else:
            return str(list_order)
    elif list_type == "upper-alpha": # 大写英文字母
        if list_order > 26:
            return ""
        return chr(64+list_order)
    elif list_type == "lower-alpha": # 小写英文字母
        if list_order > 26:
            return ""
        return chr(96+list_order)
    elif list_type == "lower-greek": # 希腊字母
        if list_order >24:
            return ""
        return chr(0x03B0 + list_order)
    elif list_type in ["lower-roman","upper-roman"]: # 罗马数字
        if list_order > 5000:
            return ""
        int_to_roman = [(1000,"M"),(900,"CM"),(500,"D"),(400,"CD"),
                        (100,"C"),(90,"XC"),(50,"L"),(40,"XL"),
                        (10,"X"),(9,"IX"),(5,"V"),(4,"IV"),(1,"I")]
        index_shift = 0
        for i in [1000,900,500,400,100,90,50,40,10,9,5,4]:
            if list_order < i:
                index_shift += 1
            else:
                break
        roman_num = ""
        for number,roman in int_to_roman[index_shift:len(int_to_roman)]:
            count,list_order = divmod( list_order ,number)
            roman_num += roman * count
            if list_order == 0:
                break
        if list_type == "lower-roman":
            roman_num = roman_num.lower()
        return roman_num
    elif list_type == "cjk-ideographic": # 中文数字
        if list_order > 100000:
            return ""
        arab_num = str(list_order)
        l = len(arab_num)
        unit = ['','','十','百','千','万']
        num_zh = ['零','一','二','三','四','五','六','七','八','九']
        cn_num = ''
        last_n = -1
        for n in arab_num:
            n = int(n)
            if n > 0:
                cn_num += num_zh[n] + unit[l]
            elif last_n != 0:
                cn_num += num_zh[n]
            l -= 1
            last_n = n
        if cn_num[0:2] == "一十":
            cn_num = cn_num[1:]
        if len(cn_num) > 1 and cn_num[-1] == '零':
            cn_num = cn_num[:-1]
        return cn_num
    return ""

#递归遍历DOM树
def recursive(etree_node,css_obj,parent_font_serif = [],parent_list_type = "disc",list_order = 0):
    font_serif = parent_font_serif #继承父节点font-family设置
    list_type = parent_list_type
    for sel in css_obj.font_selectors:
        if selector_match(etree_node,sel) == True:
            font_serif = css_obj.font_selectors[sel]
            if font_serif == ["inherit"]:
                font_serif = parent_font_serif
            break

    addtion = ""

    if etree_node.tag in ["ul","ol","li"]:
        li_style_matched = False
        for sel in css_obj.list_selectors:
            if selector_match(etree_node,sel) == True:
                list_type = css_obj.list_selectors[sel]
                li_style_matched = True
                break
        if not li_style_matched:
            if etree_node.tag == "ol":
                list_type = "decimal"
            elif etree_node.tag == "ul":
                list_type = "disc"
        if etree_node.tag == "li":
            if list_type in ["none","disc","circle","square"]:
                addtion = ""
            else:
                addtion = turn_order(list_order,list_type)
    
    #将当前节点的文本映射到所应的字体设置中
    text = etree_node.text if etree_node.text else ''
    text += addtion

    #进入下一个节点
    list_order = 0
    for child_node in etree_node:
        PARENT_MAP[child_node] = etree_node
        #如果前面没有清理注释，这里需要加入if type(child_node) != lxml.etree._Comment
        if child_node.tag == "li":
            try:
                list_order = int(child_node.attrib["value"])
            except:
                list_order += 1
        if child_node.tag not in ['br','hr','svg','img']:
            recursive(child_node,css_obj,font_serif,list_type,list_order)
        if child_node.tail:
            text += child_node.tail
 
    if font_serif:
        for font in font_serif:
            loss = make_font_mappings(css_obj.fontfamily_to_id[font],text)
            if loss != "":
                text = loss
            else:
                break
        # 20220608 修改遗漏字符提醒规则
        if loss != "":
            for ch in loss:
                manifest_id = css_obj.fontfamily_to_id[font]
                if ch not in FONT_MAPPINGS[manifest_id][1]:
                    FONT_MAPPINGS[manifest_id][1] += ch

@contextmanager
def make_temp_directory():
    ''' creates a temp folder '''
    temp_dir = tempfile.mkdtemp()
    yield temp_dir
    shutil.rmtree(temp_dir)

def subset_font(font_name, text):
    root, ext = path.splitext(font_name)
    output_font_name = root + '.subset' + ext
    options = subset.Options()
    options.layout_features = '*'
    font = subset.load_font(font_name, options)
    subsetter = subset.Subsetter(options)
    subsetter.populate(text=text)
    subsetter.subset(font)
    subset.save_font(font, output_font_name, options)
    font.close()

def run(bk):

    start = time.time()

    print('SIGIL字体子集化工具 V5.10.2 说明：\n'+
          '\n'+
          '1. 本插件简单模拟CSS规则，将设置有效的字体与对应的文本进行匹配并子集化。\n'+
          '2. CSS引用形式支持link引用、@import引用、style元素、style内联样式。\n'+
          '3. 插件可根据CSS各类选择器优先级判断节点字体属性继承关系，!important优先级设置\n'+
          '   也是有效的。基本上简单模拟浏览器对一个节点的CSS属性解析情况，这种程度的模拟\n'+
          '   可令epub制作者在CSS代码上自由发挥而不必担心插件失效。\n'+
          '4. 插件支持多字族设置，即font-family:"Font1","Font2"这种设置。插件将按照字族顺序,\n'+
          '   先裁剪Font1，如果Font1有缺字再从Font2查找并裁剪Font2...\n'+
          '5. 所有子集化的中文字体都带有‘的’字。(兼容多看APP)\n'+
          '6. 可支持子集化的字体包括 TTF 、 OTF 字体。\n'+
          '7. 字体裁剪后会输出匹配到的字符与所缺乏的字符。\n'+
          '   当字体不需要裁剪时则不会显示匹配到的字符，仅显示缺乏字符。\n'+
          '\n'+
          '【注意事项】\n\n' +
          '1. 请通过font-family设置字族，不支持<font>元素或font属性的设置。\n' +
          '2. 暂无法识别伪类、伪元素、兄弟选择器中的字族设置。\n' +
          '3. <style>元素必须写在<head>元素内才能被程序解析。\n' +
          '4. 若导入epub的字体文件不被使用（不包含任何字符子集），则将自动被清出epub。\n'+
          '\n　　　　　　　　　　　　　　　　　　　　　　　　　　        ——Ichigo250')

    css_list,old_css_list = [],[]
    deleted_fonts = []
    invalid_manifest_id = []
    global book
    book = bk
    
    #sigil的缓冲文件夹路径
    global EBOOK_ROOT
    EBOOK_ROOT = book._w.ebook_root

    #初始化FONT_DIC, ID_TO_BOOKPATH, LWCASE_BOOKPATH_TO_ID
    for manifest_id, href, mime in book.manifest_iter():
        if  book.launcher_version() >= 20190927:
            bookpath = book.id_to_bookpath(manifest_id)
        else:
            bookpath = 'OEBPS/' + href
        try:
            book.readfile(manifest_id)
        except:
            invalid_manifest_id.append(manifest_id)
            continue
        else:
            if RE_COMPILE['font-ext'].match(href):
                original_font_path = r''+ path.join(EBOOK_ROOT,bookpath)
                CMAP[manifest_id] = TTFont(original_font_path).getBestCmap().keys()
                LWCASE_BOOKPATH_TO_ID[bookpath.lower()] = manifest_id
                FONT_DIC[manifest_id] = original_font_path
            elif mime == 'text/css':
                LWCASE_BOOKPATH_TO_ID[bookpath.lower()] = manifest_id
            ID_TO_BOOKPATH[manifest_id] = bookpath
            
    #初始化FONT_MAPPINGS
    for manifest_id in FONT_DIC.keys():
            FONT_MAPPINGS.setdefault(manifest_id,['',''])

    print('\n请稍候： ',end='')

    for fid,href in book.text_iter():

        if fid in invalid_manifest_id:
            continue

        html = book.readfile(fid)
        test = html.split("\r\n")
        css_list,html = pretreatment(html)
        if css_list == [] and re.search('font-family',html) == None:
            continue
        if css_list != old_css_list and css_list != []:
            current_bookpath = ID_TO_BOOKPATH[fid]
            css_text = integrate_css_text(css_list,current_bookpath)
            css_obj = CssObject(css_text)
            old_css_list = css_list
        global PARENT_MAP
        PARENT_MAP = {}
        test = html.split("\r\n")
        etree_root = cElementTree.fromstring(html)
        etree_body = etree_root.find("body")
        PARENT_MAP[etree_root] = None
        PARENT_MAP[etree_body] = etree_root
        print(' * ',sep='',end='')
        recursive(etree_body,css_obj) #递归遍历text文件
    print('\n')

    for manifest_id in FONT_MAPPINGS.keys():
        if FONT_MAPPINGS[manifest_id][0] != '':
            FONT_MAPPINGS[manifest_id][0] += '的' #兼容多看，多看中文字体必须带“的”才能显示。
    #将FontMappings中重复的字符去除并开始子集化
    for manifest_id in FONT_DIC.keys():
        original_font_path = FONT_DIC[manifest_id]
        text = FONT_MAPPINGS[manifest_id][0]
        loss = FONT_MAPPINGS[manifest_id][1]
        font_name = path.basename(original_font_path)
        _, ext = path.splitext(font_name)
        original_font_size = path.getsize(original_font_path)
        if text != '': #判断字体在epub中是否有应用
            print('\n\n'+'='*40 + '\n' +
                  '字体名称: ', font_name +  '...\n' +
                  '字体文件原始大小: ', original_font_size,'Byte')
            #开始字体子集化
            try:
                subset_font(original_font_path, text) 
                stderr = b''
            except Exception as e:
                stderr = str(e).encode('utf-8')
            #显示字体子集化状态
            if stderr == b'':
                subset_font_path = original_font_path.replace(ext, '.subset' + ext)
                subset_font_size = path.getsize(subset_font_path)
                percentage = '({0:.2f}%)'.format(subset_font_size/original_font_size * 100)
                print('子集化后字体大小: ', subset_font_size,'Byte', percentage)
                print('='*40)
                
                # 将子集化后体积更小的字体替换掉原字体
                if subset_font_size < original_font_size:
                    with open(subset_font_path, 'rb') as file:
                        subset_font_data = file.read()
                    os.remove(subset_font_path)
                    book.writefile(manifest_id, subset_font_data)
                    if len(text) < 500:
                        print('字体包含的字符:\n' + text +'\n')
                    else:
                        print('字体包含的字符数量： ',len(text),' 个 【字符数 ＞ 500 ，仅显示字符数量】\n')
                else:
                    os.remove(subset_font_path)
                #检查字体中匹配到但缺乏的字符
                if loss != "":
                    print(' '+'！'*22)
                    if len(loss) <= 100:
                        print('字体缺乏的字符：\n',list(loss),'\n')
                    else:
                        print('字体缺乏的字符数量为： ',len(loss),' 个 【字符数 ＞ 100 ，仅显示字符数量】\n')
            else:
                error_messages = stderr.decode("utf-8")
                print('子集化失败: ' + str(error_messages))
        else:
            #删除没有应用到的字体
            deleted_fonts.append(font_name)
            os.remove(original_font_path)
            book.deletefile(manifest_id)

    for font_name in deleted_fonts:
        print('\n\n'+'='*40 +'\n' +
                '字体名称: ', font_name +  '...' +'\n' +
                '='*40 + '\n' +
                ' '+'！'*22 + '\n'
                '该字体未能匹配到任何字符，已从epub中清除。' +'\n')

    if invalid_manifest_id != []:
        print('\n！！！发现 OPF 存在无效的 Manifest Id： ',end='')
        temp_ = ''
        for invalid_id in invalid_manifest_id:
            temp_ += invalid_id+', '
        print(temp_[0:-2]+'\n')
    end = time.time()
    print('\n' , '-'*7 + '程序处理结束,耗时%.3f秒'%(end-start) +'-'*7)
    return 0
 

if __name__ == "__main__":
    epub_src = "test3.epub"
    bk = EpubBook(epub_src,is_extract=True)
    print(bk._w.ebook_root)
    run(bk)
