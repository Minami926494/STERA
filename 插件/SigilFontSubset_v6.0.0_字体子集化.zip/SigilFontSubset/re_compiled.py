#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from re import compile
#正则预编译
RE_COMPILE = {
#run
"font-ext":compile(r'(?i).*\.w?[ot]tf$'),
#CssFont::__init__
"@font-face": compile(r'(?s)@font-face{(.*?)}|(\^\|.*?\|\$)+'),
#CssFont::get_family_dic
"src:url":compile(r'(?i).*src:[^;]*url\(.*?\.w?[ot]tf *[\'\"]?\)'),
"findall-url":compile(r'(?i)url\([\'\"]?([^:\),]*\.w?[ot]tf)'),
#CssFont::get_selector
"sel-fseri":compile(r'([a-zA-Z_\.\*\[#!][^{}/;]*?)({[^{}]*?font-family[^{}]*?})'),
"sel-liststyle":compile(r'([a-zA-Z_\.\*\[#!][^{}/;]*?)({[^{}]*?list-style[^{}]*?})'),
#find_attr_not_covered
"font-family-!":compile(r'font-family:([^;\,\!\}][^;\}:]*?)!important(?=$|[;\}])'),
"src-!":compile(r'src:([^;\,\!\}][^;\}]*?)!important(?=$|[;\}])'),
"list-style-!":compile(r"list-style(?:-type)?:([a-zA-Z\- ])*!important(?=$|[;\}])"),
"font-family":compile(r'font-family:([^:;,!}\r\n\t ][^;\}:]*)(?=$|[;\}])'),
"src":compile(r'src:([^;,!\}\r\n\t ][^;\}]*)(?=$|[;\}])'),
"list-style":compile(r"list-style(?:-type)?:([a-zA-Z\- ]*)(?=$|[;\}])"),
"unicode-set-!":compile(r'\uFFFF'),
"unicode-set":compile(r'unicode-set:([^:;,!}][^;\}]*)(?=$|[;\}])'),
"unicode-add-!":compile(r'\uFFFF'),
"unicode-add":compile(r'unicode-add:([^:;,!}][^;\}]*)(?=$|[;\}])'),
"unicode-del-!":compile(r'\uFFFF'),
"unicode-del":compile(r'unicode-del:([^:;,!}][^;\}]*)(?=$|[;\}])'),
#integrate_css_text
#这部分表达式在CSS文档清理多余空格之前使用，需要注意对空白符的兼容
"@import":compile(r'(?i)@import[\r\n\t ]*(?:(?P<u>url\([\r\n\t ]*)|(?P<q>[\"\']))(?P<q2>[\"\']?)([^\'\"\(\)\r\n]*\.css)(?P=q2)(?(u)[\r\n\t ]*\)|(?P=q))[\r\n\t ]*(?:;|$)'),
"link":compile(r'(?i)<link[^>]*?href[\r\n\t ]*=[\r\n\t ]*([\"\'])[\r\n\t ]*([^\'\">]*?\.css)[\r\n\t ]*\1'),
"style":compile(r'(?s)<style[^>]*>(.*?)</style>'),
"in_style":compile(r'!style\d+{.*?}'),
"css_notes":compile(r'(?s)/\*.*?\*/')
}

RE_CLEAN = {
#pretreatment
"change-xmlns":compile(r"(<[^>]* )xmlns([ \t\r\n]*=)"),#用xml模块处理最好去掉xmlns省下一些麻烦
"link_or_style":compile(r'(?s)<link[^>]*[\r\n\t ]rel[\r\n\t ]*=[\r\n\t ]*[\'\"][\r\n\t ]*stylesheet[\r\n\t ]*[\'\"][^>]*>|<style[^>]*>.*?</style>'),
# 这表达式需要注意一定要捕获style=""里面的内容，并在对应代码填写正确分组
"in_style_pre":compile(r'<.*?style=([\'\"])(.*?)\1.*?>'), 
"html_notes":compile(r'(?s)<!--.*?-->'),
"xml-doctype":compile(r'<\?xml[^>]*>|<!DOCTYPE[^>]*>'),
"search_head":compile(r'(?s)<head>.*?</head>'),
#make_font_mappings
"chars_blank":compile(r'[\x20\r\n\t]+')
}

RE_SEL_MATCH = {
    'value_str':compile(r'[\'\"]'),
    'attr_name':compile(r'[\*=\^\$\|\~]'),
    'value':compile(r'[\*=\^\$\|\~]'),
    'operator':compile(r'([\*\=\^\$\|\~]{1,2})')
}