import re
# CSS文档最简化，清除所有没必要的换行符，空格，制表符
def clear_css(text):    
    text = text.strip(" \r\n\t")
    new_text = ""
    # 引号正确结束引用的情况只有以种：遇到另一个相同引号形成对称引号。此外同一行里遇到分号;或右花括号}等都无法结束引用。
    # 当然还有一种结束引用的方法，但它是由错误语法导致的错误结束：即引号里存在换行符，且换行符后面存在分号；或右花括号则可以结束引用；
    # 引号里如果存在换行符，会导致引用内容作废，但换行符后面的分号和花括号可以结束引用，不会因为缺乏对称引号而影响后面的CSS规则。
    double_quo = False
    single_quo = False
    quo_break = False # 当引号引用内容存在换行符时为True
    annotation = False # 注释开始
    bracket = False # 中括号，属性选择器内部
    # 花括号判断规则为，如果 brace > 0，则处于花括号内部，brace = 0 则处于花括号外部，brace < 0 则右括号多余（错误语法） }。
    # 当程序读到左括号 { 则 brace +1，如果此时 brace < 0，则 brace 归零后再 +1，当程序读到右括号 } 则 brace -1。
    brace = 0 #暂时不用
    #----------------------------
    index = -1
    while index < len(text)-2:
        index += 1
        ch = text[index]
        next_ch = text[index+1]

        # 处理注释(该部分放在最前面，则后面不需要再判定是否注释环境)
        if annotation:
            if ch == "/" and next_ch == "*":
                index += 1
            elif ch == "*" and next_ch == "/":
                annotation = False
                index += 1
                if index > len(text)-2:
                    continue
                next_ch = text[index+1]
                while next_ch in " \n\t\r":
                    index += 1
                    if index > len(text) - 2:
                        break
                    next_ch = text[index+1]
            continue

        # 引用内容处理（该部分提前处理，后面不需要再判定是否引用环境）
        if double_quo or single_quo:
            if ch == "\n":
                quo_break = True
            # 正常结束引用
            if double_quo and ch == '\"':
                quo_break = False
                double_quo = False
            elif single_quo and ch == "\'":
                quo_break = False
                single_quo = False
            # 非正常结束引用
            if quo_break and ch in ";}":
                quo_break = False
                single_quo,double_quo = False,False
                index -= 1
                continue
            new_text += ch
            continue
        else:
            # 开始引用
            if ch == '\"':
                double_quo = True
            elif ch == "\'":
                single_quo = True
        
        # 中括号，属性选择器内部
        if bracket == True:
            if ch in "]{":
                bracket = False
            if ch in " \n\t":
                if new_text[-1] == "[":
                    continue
                if new_text[-1] == "=":
                    continue
                if next_ch in " \n\t]":
                    continue
                if next_ch in "~|^$*":
                    continue
                if next_ch == "=" and new_text[-1] not in "~|^$*":
                    continue
                new_text += " "
                continue
            new_text += ch
            continue
        elif ch == "[":
            bracket = True
            new_text += ch
            continue
        
        #处理空白符
        if ch in " \n\t":
            if next_ch in " \n\t\r,;}{:)+~>!": # 空白符后面遇到这些符号，则除去空白
                continue
            else:
                new_text += " "
                continue
        if ch in ",;}{:(+~>!":  # 这些符号后面遇到空白符，则除去空白
            new_text += ch
            while next_ch in " \n\t\r":
                index += 1
                if index >= len(text) - 1:
                    break
                next_ch = text[index + 1]
            continue
        if ch == "\r":
            continue
        
        #注释开头
        if ch == "/" and next_ch == "*":
            annotation = True
            index += 1
            continue

        new_text += ch
    # end while

    if index == len(text) -2:
        new_text += text[-1]
    return new_text

#计算bookpath
def get_bookpath(relative_path,refer_bkpath):
    '''注意：refer_bkpath若路径是文件夹，则以‘\’或‘/’号结尾，文件则否'''
    # relative_path 相对路径，一般是href
    # refer_bkpath 参考的绝对路径

    relative_ = re.split(r'[\\/]',relative_path)
    refer_ = re.split(r'[\\/]',refer_bkpath)
    
    back_step = 0
    while relative_[0] == '..':
        back_step += 1
        relative_.pop(0) 

    if len(refer_) <= 1:
        return '/'.join(relative_)
    else:
        refer_.pop(-1)

    if back_step < 1:
        return '/'.join(refer_+relative_)
    elif back_step > len(refer_):
        return '/'.join(relative_)

    #len(refer_) > 1 and back_setp <= len(refer_):
    while back_step > 0 and len(refer_) > 0:
        refer_.pop(-1)
        back_step -= 1
    
    return '/'.join(refer_ + relative_)

#计算可引用的相对路径集（包含从最短到最长的相对路径）
def get_all_relativepath(from_path,to_path,low = False):
    all_relativepath = []
    shortest = book.get_relativepath(from_path,to_path) #计算最短相对路径
    if low:
        shortest = shortest.lower()
    all_relativepath.append(shortest)
    temp = re.match(r'(\.\./)*',shortest)
    pre_back = int(len(temp.group())/3) if temp else 0 # 计算最短相对路径的后退级数
    back = 0
    back_dir = path.dirname(from_path)
    while back_dir:
        back += 1
        if back > pre_back: #当后退级数超过最短相对路径的后退级数，开始计算相对路径
            rpath = book.get_relativepath(back_dir,to_path)
            rpath = '../'*back + rpath
            if low:
                rpath = rpath.lower()
            all_relativepath.append(rpath)
        back_dir = path.dirname(back_dir)
    return all_relativepath



import html.entities
HTML_ENTITY = html.entities.name2codepoint.copy()
for name in ["amp","lt","gt"]:
    del HTML_ENTITY[name]
def decode_xml_entities(text):
    def fix(m):
        c = m.group(1)
        if c in HTML_ENTITY:
            return chr(HTML_ENTITY[c])
        else:
            if c[0] == "#" and len(c) > 1:
                # numeric
                if c[1] == "x" and len(c) > 2:
                    try:
                        i = int(c[2:], 16)
                        return chr(i)
                    except:
                        # error
                        return ''
                else:
                    try:
                        i = int(c[1:])
                        return chr(i)
                    except:
                        # error
                        return ''
            # error!
            return m.group()
    #return re.sub(r">[^>]*<",lambda m:re.sub(r"&([#a-zA-Z0-9]+);",fix,m.group()),text)
    return re.sub(r"&([#a-zA-Z0-9]+);",fix,text)

#清除重复字符
def filter_string(s):
    mytext = "".join(set(s))
    return mytext
