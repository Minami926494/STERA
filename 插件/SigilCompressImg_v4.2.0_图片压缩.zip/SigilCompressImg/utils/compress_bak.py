#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os,errno,shutil,random
import subprocess
from threading import Thread
from PyQt5.QtGui import  QImage,QTransform
from PyQt5.QtCore import Qt,QSize,QByteArray,QBuffer,QIODevice
from PIL import Image

if __name__ == "__main__":
    from complement import *
else:
    from utils.complement import *

TEMPDIR = make_temp_dir()
SUBPROCESS = []

def ImagesProcess(file_path,args):

    # args 键含义：
    # ROTATE    旋转 0 90 180 270
    # SIZE      限定尺寸 包含尺寸限定值或尺寸百分比
    # CONV      图片格式转JPEG、WEBP开关
    # CONV_RATE 图片转格式质量压缩率
    # J_RATE    JPEG压缩质量比率
    # W_RATE    WEBP质量压缩比率
    # ULOSS     无损压缩开关
    # ULOSS_LV  无损压缩级别 默认为4 （1-6）
    # ULOSS_WP  WEBP无损压缩级别 默认为7 （0-9）
    # EXT       图片后缀名
    # OPERATE   操作数量，0则表示无任何操作

    #跳过不需要操作的图片
    blank_log = {'SRC':file_path,'OUT':None,'ROTATE':0,'SIZE':None}
    if args['OPERATE'] == 0:
        return blank_log
    elif args['OPERATE'] == 1:
        if args['EXT'].upper in ['PNG','BMP','GIF'] and args['J_RATE'] is not None:
            return blank_log
        elif args['EXT'].upper in ['JPG','JPEG'] and args['CONV'] == 'JPG':
            return blank_log
        elif args['EXT'].upper == 'WEBP' and args['CONV'] == 'WEBP':
            return blank_log

    tempfile = None
    #返回值修饰
    def log(log_dic,rotate,size):
        log_dic['ROTATE'] = rotate if rotate else 0
        log_dic['SIZE'] = True if size is not None else False
        return log_dic
    #图片旋转处理
    def rotateImg(img,angle = 0):
        trans = QTransform()
        trans.rotate(angle)
        return img.transformed(trans)
    #图片尺寸压缩
    def resizeImg(img,size,returnSize = False):
        if type(size).__name__ == 'tuple':
            w,h = size[0],size[1]
            rateW = w / img.width()
            rateH = h / img.height()
            rateW = rateW if 0 < rateW < 1 else 1
            rateH = rateH if 0 < rateH < 1 else 1
            rate = rateW if rateW <= rateH else rateH
        elif type(size).__name__ == 'int':
            rate = size/100
        if 0 < rate < 1:
            W = int(img.width() * rate)
            H = int(img.height() * rate)
            if returnSize == True: # 仅返回尺寸，cwebp用到
                return (W,H)
            return img.scaled(QSize(W,H),transformMode=Qt.TransformationMode.SmoothTransformation)
        else:
            if returnSize == True:
                return None
            return img

    img = QImage()
    if not img.load(file_path):
        raise ValueError('%s is not a valid image file' % file_path)

    if args['CONV'] == 'JPG':
        if args['EXT'].upper() in ['PNG','BMP','GIF','WEBP']:
            args['EXT'] = 'jpg'
            args['J_RATE'] = args['CONV_RATE']
    elif args['CONV'] == 'WEBP':
        if args['EXT'].upper() in ['PNG','BMP','GIF','JPG','JPEG']:
            args['EXT'] = 'webp'
            args['W_RATE'] = args['CONV_RATE']
            args['ULOSS_WP'] = 7

    #处理WEBP
    if args['EXT'].upper() == 'WEBP':

        if args['ROTATE'] in [90,180,270]:
            img = rotateImg(img,args['ROTATE'])
            Size = resizeImg(img,args['SIZE'],True) if args['SIZE'] else None #重设尺寸的步骤必须在旋转图片之后
            file_name = os.path.splitext(os.path.basename(file_path))[0]
            rdstr = ''.join(str(random.randint(1000,9999)))
            tempfile = os.path.join(TEMPDIR,file_name + '_temp{}.'.format(rdstr) + 'PNG')
            img.save(tempfile,'PNG')
            return log(encode_webp(file_path,args['W_RATE'],args['ULOSS_WP'],Size,tempfile = tempfile,conv = args['CONV']), args['ROTATE'], args['SIZE'])
        else:
            Size = resizeImg(img,args['SIZE'],True) if args['SIZE'] else None
            return log(encode_webp(file_path,args['W_RATE'],args['ULOSS_WP'],Size,conv = args['CONV']), args['ROTATE'], args['SIZE'])
    
    #处理PNG、BMP、GIF
    if args['EXT'].upper() in ['PNG','BMP','GIF']:

        if args['ROTATE'] in [90,180,270]:
            img = rotateImg(img,args['ROTATE'])

        if args['SIZE']: #重设尺寸的步骤必须在旋转图片之后
            img = resizeImg(img,args['SIZE'])

        if args['ROTATE'] or args['SIZE'] or args['CONV']:
            #必须通过创建临时文件中转的情况
            file_name = os.path.splitext(os.path.basename(file_path))[0]
            rdstr = ''.join(str(random.randint(1000,9999)))
            tempfile = os.path.join(TEMPDIR,file_name + '_temp{}.'.format(rdstr) + args['EXT'])
            img.save(tempfile,args['EXT'])
            return log(optimize_png(file_path,args['ULOSS_LV'],tempfile=tempfile), args['ROTATE'], args['SIZE'])
        else:
            return log(optimize_png(file_path,args['ULOSS_LV']), args['ROTATE'], args['SIZE'])

    #处理JPEG
    if args['EXT'].upper() in ['JPG','JPEG']:


        if args['ROTATE'] in [90,180,270]:
            img = rotateImg(img,args['ROTATE'])

        if args['SIZE']: #重设尺寸的步骤必须在旋转图片之后
            img = resizeImg(img,args['SIZE'])

        if args['ULOSS'] and not ( args['ROTATE'] or args['SIZE'] or args['CONV'] or args['J_RATE'] ):
            return log(optimize_jpeg(file_path,conv=args['CONV']), args['ROTATE'], args['SIZE'])

        elif args['ULOSS'] and ( args['ROTATE'] or args['SIZE'] or args['CONV'] or args['J_RATE'] ):
            #必须通过创建临时文件中转的情况
            file_name = os.path.splitext(os.path.basename(file_path))[0]
            rdstr = ''.join(str(random.randint(1000,9999)))
            tempfile = os.path.join(TEMPDIR,file_name + '_temp{}.'.format(rdstr) + args['EXT'])
            img.save(tempfile,args['EXT'],args['J_RATE'] or 100)
            return log(optimize_jpeg(file_path,tempfile=tempfile,conv=args['CONV']), args['ROTATE'], args['SIZE'])

        else:
            ba = QByteArray()
            buf = QBuffer(ba)
            buf.open(QIODevice.OpenModeFlag.WriteOnly)
            if not img.save(buf, 'PPM'):
                raise ValueError('Failed to export image to PPM')
            input_data = ReadOnlyFileBuffer(ba.data())
            return log(encode_jpeg(file_path,args['J_RATE'] or 100,input_data,conv=args['CONV']), args['ROTATE'], args['SIZE'])



def optimize_jpeg(file_path, tempfile = None , conv = None):
    exe = os.path.join(os.path.dirname(__file__),'jpegtran.exe')
    cmd = [exe] + '-copy none -optimize -progressive -maxmemory 100M -outfile'.split() + [False, True]
    return run_optimizer(file_path,cmd,False,None,tempfile,conv)

def optimize_png(file_path, level=4,tempfile = None , conv = None):
    #level goes from 1 to 7 with 7 being maximum compression
    exe = os.path.join(os.path.dirname(__file__),'optipng.exe')
    cmd = [exe] + '-fix -clobber -strip all -o{} -out'.format(level or 1).split() + [False, True]
    return run_optimizer(file_path,cmd,False,None,tempfile,conv)

def encode_jpeg(file_path, quality=85 ,input_data = None, tempfile = None , conv = None):
    quality = max(0, min(100, int(quality)))
    exe = os.path.join(os.path.dirname(__file__),'cjpeg.exe')
    cmd = [exe] + '-optimize -progressive -maxmemory 100M -quality'.split() + [str(quality)]
    return run_optimizer(file_path, cmd, True, input_data, tempfile, conv)

def encode_webp(file_path, quality = None, uloss_lv = 7, size = None, tempfile = None , conv = None):
    exe = os.path.join(os.path.dirname(__file__),'cwebp.exe')
    if quality:
        if size:
            cmd = [exe] + '-q {} -m 4 -resize {} {} -quiet -mt'.format(quality,size[0],size[1]).split() + [True,'-o',False]
        else:
            cmd = [exe] + '-q {} -m 4 -quiet -mt'.format(quality).split() + [True,'-o',False]
    else:
        if size:
            cmd = [exe] + '-z {} -resize {} {} -lossless -quiet -mt'.format(uloss_lv or 0,size[0],size[1]).split() + [True,'-o',False]
        else:
            cmd = [exe] + '-z {} -lossless -quiet -mt'.format(uloss_lv or 0).split() + [True,'-o',False]

    return run_optimizer(file_path,cmd,False,None,tempfile,conv)

def run_optimizer(file_path, cmd, as_filter=False, input_data=None , tempfile = None , conv = None):
    file_path = os.path.abspath(file_path)
    if tempfile:
        tempfile = os.path.abspath(tempfile)
    cwd = TEMPDIR
    basename = os.path.basename(file_path)
    if conv == 'JPG':
        basename = os.path.splitext(basename)[0] + '.jpg'
    elif conv == 'WEBP':
        basename = os.path.splitext(basename)[0] + '.webp'
    ext = os.path.splitext(file_path)[1] 
    outfile = os.path.join(TEMPDIR,basename)
    if not os.path.exists(outfile):
        open(outfile,'w+').close()
    fd = os.open(outfile,os.O_RDWR)
    try:
        if as_filter:
            outf = os.fdopen(fd, 'wb') #通过文件描述符创建一个文件对象。
        else:
            os.close(fd)
        if tempfile:
            infile, oname = tempfile, os.path.basename(outfile)
        else:
            infile, oname = file_path, os.path.basename(outfile)
        def repl(q, r):
            #将cmd元组中的True值对应位置替换为输入名，False值对应位置替换为输出名。
            cmd[cmd.index(q)] = r
        if not as_filter:
            repl(True, infile), repl(False, oname)
        stdin = subprocess.PIPE if as_filter else None
        stderr = subprocess.PIPE if as_filter else subprocess.STDOUT
        creationflags = subprocess.DETACHED_PROCESS
 
        p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=stderr, stdin=stdin, creationflags=creationflags)
        SUBPROCESS.append(p)
        

        stderr = p.stderr if as_filter else p.stdout
        if as_filter:
            src = input_data or open(file_path, 'rb')
            def copy(src, dest):
                try:
                    shutil.copyfileobj(src, dest)
                finally:
                    src.close(), dest.close()
            inw = Thread(name='CopyInput', target=copy, args=(src, p.stdin))
            inw.daemon = True
            inw.start()
            outw = Thread(name='CopyOutput', target=copy, args=(p.stdout, outf))
            outw.daemon = True
            outw.start()
        raw = force_unicode(stderr.read())
        if p.wait() != 0:
            print(raw)
            raise
        else:
            if as_filter:
                #join(60.0) 等待该进程60秒
                outw.join(60.0), inw.join(60.0)
            shutil.copystat(file_path, outfile)
            return {'SRC':file_path,'OUT':outfile,'ROTATE':0}
    except Exception as e:
        print(e)
        raise
    finally:
        try:
            os.remove(outfile + '.bak')  # optipng creates these files
        except EnvironmentError as err:
            if err.errno != errno.ENOENT:
                raise

if __name__ == "__main__":
    pass