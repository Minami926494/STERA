

class UFOLibError(Exception):
    pass


class GlifLibError(UFOLibError):
    pass
